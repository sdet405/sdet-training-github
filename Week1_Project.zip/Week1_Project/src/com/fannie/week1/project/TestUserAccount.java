package com.fannie.week1.project;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.Test;

/**
 * 
 * @author SDET405
 * 
 * This Junit is still in progress. This file will be updated once the implementation is complete.
 *
 */
public class TestUserAccount {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	public void insertBankAcctData(Connection con, int acctNo, String name){
		
		//implement this code
	}

}
