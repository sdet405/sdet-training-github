package com.fannie.week1.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 
 * @author SDET405
 * 
 * This class demonstrates inserting, updating and viewing records in a table via the JDBC driver for Oracle. 
 *
 */
public class UserAccountDBOperations {
	
	public void insertBankAcctData(Connection con, int accountNo, String accountHolderName, double accBalance){
			
		try{
			//create the statement object
			PreparedStatement stmt = null;
                      
            stmt = con.prepareStatement("insert into account values(?,?,?)");
            stmt.setInt(1, accountNo);
            stmt.setString(2, accountHolderName);//1 specifies the first parameter in the query
			stmt.setDouble(3, accBalance);
             
			int i = stmt.executeUpdate();
			System.out.println(i+" record(s) inserted");
			
            con.close();
            			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void viewBankAccData (Connection con){
		
		 try {
			Statement readStmt = con.createStatement();
			ResultSet rs = readStmt.executeQuery("select * from account");
			
			while (rs.next()){
				System.out.println("Account No : "+rs.getString(1));
				System.out.println("Account Holder Name: "+rs.getString(2));
				System.out.println("Account Balance : "+rs.getDouble(3));
			}
			
			con.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public void updateBalanceForUser(Connection con, double balance, int acctNo){
		
		PreparedStatement stmt = null;
		
		try {
		
			System.out.println("updateBalanceForUser ()....");
			stmt = con.prepareStatement("update account set account_balance=? where account_no = ?");
			stmt.setDouble(1, balance);
			stmt.setInt(2, acctNo);
			            			
			int i = stmt.executeUpdate();
			
			System.out.println(i + " records updated");
			
			con.close();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        
	}

	public static void main(String[] args) {

		UserAccountDBOperations userAccDB = new UserAccountDBOperations();
			
	
		try {
			//1. Load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//2. Create the Connection object
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sdettrainee1","ora@pwd");
			
			//Insert data into the table
			userAccDB.insertBankAcctData(con, 1, "Sushma Matlock",500.00);
			
			//View inserted record
			System.out.println("Record data before updating the balance...");
			userAccDB.viewBankAccData(con);
			
			//Update data in the table
			userAccDB.updateBalanceForUser(con, 100000.00, 1);
			
			//View updated record
			System.out.println("Record data after updating the balance...");
			userAccDB.viewBankAccData(con);

			
		} catch (ClassNotFoundException e) {		
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}		

	}

}
